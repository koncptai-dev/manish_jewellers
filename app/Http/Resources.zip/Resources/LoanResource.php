<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class LoanResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        // Monthly Payments Chart Data
        $monthlyPayments = DB::table('loan_installment_payment_details')
            ->selectRaw('YEAR(created_at) as year, MONTH(created_at) as month, SUM(installment_amount) as total_payment')
            ->groupBy('year', 'month')
            ->orderBy('year', 'desc')
            ->orderBy('month', 'desc')
            ->get();

        // Weekly Payments Chart Data
        $weeklyPayments = DB::table('loan_installment_payment_details')
            ->selectRaw('YEAR(created_at) as year, WEEK(created_at) as week, SUM(installment_amount) as total_payment')
            ->groupBy('year', 'week')
            ->orderBy('year', 'desc')
            ->orderBy('week', 'desc')
            ->get();

        return [
            'id' => $this->id,
            'plan_id' => $this->plan_id,
            'total_balance' => $this->details->sum('installment_amount'),
            'loan_amount' => $this->loan_amount,
            'no_of_months' => $this->no_of_months,
            'plan_start_date' => $this->formatDate($this->loan_date),
            'plan_end_date' => $this->formatDate($this->loan_end_date),
            'monthly_average' => $this->details->avg('installment_amount'),
            'payment_status' => 'Success',
          	'total_no_of_emi' => 6,
            'emi_remaining'=> 2,
            'emi_amount'=> 300,
            'emi_amount_remaining'=> 150,
            'chart_monthly' => $monthlyPayments,
            'chart_weekly' => $weeklyPayments,
            'details' => LoanDetailResource::collection($this->details->values()->map(function ($detail, $index) {
                $detail->installment_index = $index + 1;
                return $detail;
            })),
        ];
    }

    public function formatDate($date)
    {
        return Carbon::parse($date)->format('F jS, Y g:i A');
    }
}
