importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-messaging.js');
importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-auth.js');

firebase.initializeApp({
    apiKey: "AIzaSyCyBySSiefZitPw_SdtJ7MKv9w7bbwL4ug",
    authDomain: "altaibagold-12c2d.firebaseapp.com",
    projectId: "altaibagold-12c2d",
    storageBucket: "altaibagold-12c2d.appspot.com",
    messagingSenderId: "948376471552",
    appId: "1:948376471552:android:68bfca084be82ab535b0e5",
    measurementId: ""
});

const messaging = firebase.messaging();
messaging.setBackgroundMessageHandler(function(payload) {
    return self.registration.showNotification(payload.data.title, {
        body: payload.data.body || '',
        icon: payload.data.icon || ''
    });
});